# Phin — personal Jarvis-style assistant

A voice assistant that lives on your PC: wake word → listens → thinks (Claude
or GPT, swappable) → controls your computer / writes files / remembers things
→ talks back in a custom ElevenLabs voice.

## ⚠️ Before anything else: rotate your ElevenLabs key

You pasted a live API key in our chat. I've wired it into `.env` so the code
works right away, but treat that key as compromised — **go regenerate it in
your ElevenLabs dashboard** (Profile → API Keys) and drop the new one into
`.env`. Never paste real keys into chat, commit them to git, or hardcode them
in source files — `.env` is gitignored specifically so this doesn't happen.

## Architecture

```
main.py                  orchestrator: wake word -> STT -> LLM -> tools -> TTS
core/
  config.py              loads .env, single source of truth for settings
  llm_provider.py         swappable LLM brain: AnthropicProvider / OpenAIProvider
  tool_registry.py        tool schemas + dispatch (add new tools here)
  memory.py               SQLite: conversation log + durable "facts"
tools/
  computer.py             open apps, screenshot, click/type/hotkeys
  files.py                create .txt / .docx / .pdf, saved to Desktop
  browser.py              open URLs, new/close/switch tabs, search — no clicks
  code_editor.py          read/write/rewrite/find-replace real files on disk
voice/
  wake_word.py            openWakeWord: "Hey Jarvis" wake word (real detector model)
  stt.py                  faster-whisper, fully local
  tts.py                  ElevenLabs speech synthesis
ui/
  overlay.html            HUD-style always-on-top status widget
  server.py               Flask-SocketIO bridge (HUD <-> backend)
```

## Setup (Windows)

1. **Python 3.11+**, then:
   ```
   cd phin
   python -m venv .venv
   .venv\Scripts\activate
   pip install -r requirements.txt
   ```
2. Fill in `.env`:
   - **No budget for API keys? (default setup)** `.env` is already set to
     `LLM_PROVIDER=openai` pointing at a local
     [freellmpool](https://github.com/0xzr/freellmpool) proxy. freellmpool
     pools 24 free-tier providers (Groq, Cerebras, NVIDIA NIM, Gemini,
     OpenRouter, GitHub Models, and others) behind one endpoint with real
     failover and per-day quota tracking — several routes (Pollinations,
     OVHcloud, Kilo Gateway) need **no API key at all**. Setup:
     ```
     pip install freellmpool
     freellmpool init --yes      # detects what you already have, prints next steps
     freellmpool proxy           # starts http://localhost:8080 — leave this running
     ```
     Run `freellmpool keys add <provider>` for any of Groq/Cerebras/OpenRouter/
     etc. to unlock more models and higher daily caps beyond the keyless tier.
     Check what's actually usable right now with `freellmpool capacity status`
     or `freellmpool providers health` — this is also how you check whether a
     given provider has hit its daily limit, instead of guessing from an error.
   - **Have a budget later?** `ANTHROPIC_API_KEY` — get one at
     https://console.anthropic.com, then set `LLM_PROVIDER=anthropic` in
     `.env`. Switch providers any time — no code changes needed.
   - `ELEVENLABS_API_KEY` / `ELEVENLABS_VOICE_ID` — already filled with what
     you gave me (rotate the key first, see above).
   - `DESKTOP_PATH` — set to your actual Windows desktop path, e.g.
     `C:\Users\yourname\Desktop`.
3. **Test in text mode first** (no mic/wake-word setup needed):
   ```
   python main.py text
   ```
   Try: `"open notepad"`, `"take a screenshot"`, `"write a text file called
   test.txt that says hello"`, `"remember that my favorite editor is VS Code"`.
4. **Switch to voice mode** once text mode works:
   ```
   python main.py voice
   ```
   The wake word is **"Hey Jarvis"** by default (openWakeWord's pretrained
   model — there's no off-the-shelf "Hey Phin" model, see the note in
   `voice/wake_word.py` for training a custom one later). openWakeWord needs
   ~5MB of model files downloaded once on first run — see "Manual wake-word
   model download" below if that download fails on your network.
5. **Preview the HUD** (optional, cosmetic only right now):
   ```
   python ui/server.py
   ```
   open `http://localhost:5151`.

## Manual wake-word model download

`voice/wake_word.py` tries to auto-download openWakeWord's model files on
first run. If that fails with a network/connection error (some
firewalls/antivirus block or reset the raw connection Python's `requests`
library opens to GitHub, even though a normal browser tab to the same URL
works fine), download these 4 files manually in your browser instead:

- https://github.com/dscripka/openWakeWord/releases/download/v0.5.1/melspectrogram.onnx
- https://github.com/dscripka/openWakeWord/releases/download/v0.5.1/embedding_model.onnx
- https://github.com/dscripka/openWakeWord/releases/download/v0.5.1/silero_vad.onnx
- https://github.com/dscripka/openWakeWord/releases/download/v0.5.1/hey_jarvis_v0.1.onnx

Then move all 4 into:
```
phin\.venv\Lib\site-packages\openwakeword\resources\models\
```
(create the `models` folder if it doesn't exist). Phin detects they're
already there and skips the download entirely on the next run.

## What's real vs. what's scaffolded

- ✅ Working now: text-mode conversation loop, tool calling (open apps,
  screenshot, type/click/hotkeys, create txt/docx/pdf, browser tab control,
  read/write/rewrite any file on disk, memory remember/recall), swappable
  LLM provider, ElevenLabs voice output, local Whisper STT with noise
  calibration and low-confidence re-prompting, openWakeWord wake word
  listener ("Hey Jarvis" by default — a real trained detector model, not
  keyword-spotting).
- 🧩 Not built yet, next steps: Gmail / Notion / Google Drive integrations
  (each is its own OAuth + tool set — I'd add them one at a time so each is
  testable), packaging as a background service/tray app instead of a console

  window.

## Voice recognition

- Uses Whisper's `small.en` model (better accuracy than `base.en` on names,
  filenames, and URLs) with its built-in Silero VAD for endpointing, rather
  than a naive volume threshold.
- On startup, `stt.calibrate_noise_floor()` samples ~1.2s of room silence so
  the "user stopped talking" cutoff adapts to your actual environment instead
  of a hardcoded guess.
- Each transcription gets a confidence score. If it's too low (garbled audio,
  background noise mistaken for speech), Phin says "Sorry, I didn't catch
  that" and listens again once, instead of silently acting on a wrong
  transcription — this is the main lever against Phin doing the wrong thing
  because it misheard you.
- If misrecognition is still a problem for you specifically: try `medium.en`
  in `voice/stt.py`'s `_get_model()` (slower, meaningfully more accurate) or
  get a proper USB mic / headset — the model can only work with what the
  microphone hands it.

## Full hands-free PC control

- **Apps**: `open_app`, `close_active_window`
- **Browser**: `open_url`, `search_web`, `new_tab`, `close_tab`, `next_tab`,
  `previous_tab`, `go_to_tab_number`, `reopen_closed_tab`,
  `navigate_current_tab` — all via OS-level keyboard shortcuts, so it works
  in whatever browser (Chrome/Edge/Firefox) is focused, no clicking.
- **Code/files**: `read_file`, `write_file`, `find_replace_in_file`,
  `append_to_file`, `list_directory` — Phin can open any file on disk, discuss
  it, and rewrite it (whole-file or a targeted find/replace) purely by voice.
  It's instructed to read a file before overwriting it and to confirm before
  large/destructive rewrites.
- **Screen**: `take_screenshot`, `type_text`, `press_hotkey`

## Security notes

- `.env` holds all secrets and is gitignored — never commit it.
- `open_app`, `press_hotkey`, `close_active_window`, and all of `tools/browser.py`
  execute real actions on your PC. `write_file` and `find_replace_in_file` can
  overwrite real files anywhere on disk, not just a sandboxed folder — that's
  what makes "rewrite my code" possible, but it also means a wrong voice
  command really can overwrite something you cared about. The system prompt
  tells the model to read-before-write and confirm before destructive edits,
  but you're trusting an LLM plus a speech recognizer with real file writes —
  consider working in a git repo (so bad rewrites are one `git checkout` away)
  until you trust its judgment on your setup.
- If you eventually add Gmail/Drive/Notion, use OAuth (not raw API keys
  pasted into `.env`) so access is scoped and revocable.

## Next steps I'd suggest, in order

1. Get `ANTHROPIC_API_KEY`, run `python main.py text`, sanity-check tool calls.
2. Rotate the ElevenLabs key, confirm `tts.speak("test")` works.
3. Run `python main.py voice --native`, get comfortable with "Hey Phin" + STT accuracy.
4. (Optional) Train a real custom "Hey Phin" openWakeWord model for
   snappier/more accurate wake detection than the current Whisper
   keyword-spotting.
5. Add Gmail integration first (most requested), then Drive, then Notion.
